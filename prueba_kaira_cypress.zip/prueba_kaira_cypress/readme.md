1. npm i
2. for linux & mac
       npm start
3. for windows
       npm run start_win